from flask import Flask, render_template, request, jsonify
from logic import recommend

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/recommend", methods=["POST"])
def recommendation():

    try:

        user_data = request.get_json()

        q1 = user_data["q1"]
        q2 = user_data["q2"]
        q3 = user_data["q3"]
        q4 = user_data["q4"]
        region_key = user_data.get("region")

        results = recommend(q1, q2, q3, q4, region_key=region_key)

        return jsonify(
            results.to_dict(orient="records")
        )

    except Exception as e:

        print("ERROR:", e)

        return jsonify({
            "error": str(e)
        }), 400


if __name__ == "__main__":
    app.run(debug=True)

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import NearestNeighbors

data = pd.read_csv("Worldwide Travel Cities Dataset (Ratings and Climate).csv")

# Checked all null values, missing values and duplicated values
"""print(data.head(),"\n")
print(data.tail(),"\n")
print(data.info(),"\n")
print(data.isnull().sum(),"\n")
print(data.duplicated().sum(),"\n")
print(data.describe(include=object)) #include object forces panda to include text duuuuata
"""

# Keep a human-readable copy of the budget level before we numerically encode it,
# so we can still show "Luxury" / "Mid-range" / "Budget" in the results later.
data["budget_label"] = data["budget_level"]

# level all the numeric values to 0-1 suucaling level
budget_map = {"Budget": 1, "Mid-range": 3, "Luxury": 5}
data["budget_level"] = data["budget_level"].map(budget_map)
duration_map = {"Day trip": 1, "Short trip": 2, "Weekend": 3, "One week": 4, "Long trip": 5}

scaler = MinMaxScaler()
numeric_columns = data.select_dtypes(include=["int64", "float64"]).columns
if len(numeric_columns) > 0:
    data[numeric_columns] = scaler.fit_transform(data[numeric_columns])

# Features available in the dataset
features = ["culture", "adventure", "nature", "beaches", "nightlife", "cuisine", "wellness", "urban", "seclusion"]

# What the user sees -> actual dataset column
option_to_feature = {"Culture": "culture", "Adventure": "adventure", "Nature": "nature", "Beaches": "beaches",
                      "Nightlife": "nightlife", "Cuisine": "cuisine", "Wellness": "wellness", "Urban": "urban",
                      "Secluded": "seclusion"}

# Maps the "Featured Regions" cards shown in the UI to the actual `region`
# values used in the dataset (checked against the real data: europe,
# middle_east, asia, oceania, north_america, south_america, africa).
REGION_GROUPS = {
    "europe-me": ["europe", "middle_east"],
    "asia-pacific": ["asia", "oceania"],
    "americas": ["north_america", "south_america"],
    "africa": ["africa"],
}


def _find_city_column():
    for candidate in ["city", "City", "CITY", "destination", "Destination"]:
        if candidate in data.columns:
            return candidate
    raise ValueError("Could not find a city column in the dataset.")


def recommend(q1, q2, q3, q4, region_key=None):
    # Convert answers into dataset columns
    selected_features = [option_to_feature[q1], option_to_feature[q2], option_to_feature[q3], option_to_feature[q4]]

    # If the user picked one of the "Featured Regions" cards, narrow the
    # search down to cities in that region before finding neighbours.
    working_data = data
    if region_key:
        region_values = REGION_GROUPS.get(region_key)
        if region_values:
            filtered = data[data["region"].isin(region_values)]
            if len(filtered) > 0:
                working_data = filtered

    # Get the ratings of those 4 selected categories
    X = working_data[selected_features].values
    weights = np.array([4, 3, 2, 1])
    # Apply priority
    X_weighted = X * weights
    # Ideal city = maximum rating in all 4 selected categories
    user_preference = np.ones(4, dtype=float) * weights

    # Create KNN (never ask for more neighbours than rows available,
    # e.g. after narrowing down to a small region)
    n_neighbors = min(5, len(working_data))
    knn = NearestNeighbors(n_neighbors=n_neighbors, metric="euclidean")
    knn.fit(X_weighted)

    # Find closest cities
    distances, indices = knn.kneighbors([user_preference])

    # Get results
    results = working_data.iloc[indices[0]].copy()
    results["distance"] = distances[0]

    city_column = _find_city_column()
    display_columns = [city_column, "country", "region", "short_description", "budget_label"] + selected_features + ["distance"]
    display_columns = [col for col in display_columns if col in results.columns]

    return results[display_columns].rename(columns={city_column: "city", "budget_label": "budget"})


if __name__ == "__main__":
    # Local test. Flask will not run this block when importing the module.
    print(data.head())
    print(
        recommend("Culture", "Secluded", "Cuisine", "Nature")
    )
    print(
        recommend("Culture", "Secluded", "Cuisine", "Nature", region_key="europe-me")
    )
